package auctionhouse;

public class Auctioneer {
	public String auctioneerAddress;
	
	public Auctioneer(String auctioneerAddress) {
		this.auctioneerAddress = auctioneerAddress;
	}

}
