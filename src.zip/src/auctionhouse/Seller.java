package auctionhouse;

public class Seller {

    public String address;
    public String bankAccount;
    
    public Seller(String address, String bankAccount) {
    	this.address = address;
    	this.bankAccount = bankAccount;
    }

}
